import React, { useState, FormEvent, ChangeEvent } from "react";
// import MainPage from "../../body/MainPage";
// import Footer from "../../Common/Footer/footer";
import { useNavigate } from "react-router-dom";
import MainPage1 from "../../body/Mainpage1";
import jsonData from "../../JSON/Dropdown";
import Searchjson from "../../JSON/Search";
interface ExploreSpaceProps { }

const ExploreSpace: React.FC<ExploreSpaceProps> = () => {
    const [sidebarVisible, setSidebarVisible] = useState(true);
    const [backgroundColor, setBackgroundColor] = useState("#fff");
    const [changeProductCategory, setChangeProductCategory] = useState("");
    const [createToDate, setCreateToDate] = useState("");
    const [errors, setErrors] = useState<{ [key: string]: string }>({});
    const [mapVisible, setMapVisible] = useState(false);

    const toggleBackgroundColor = () => {
        setBackgroundColor(backgroundColor === "#fff" ? "#343a40" : "#fff");
    };

    const textClass = backgroundColor === "#fff" ? 'original-color' : 'color-changed';

    const toggleSidebar = () => {
        setSidebarVisible(!sidebarVisible);
    };

    const dashboardClass = sidebarVisible ? 'dashboard-expanded' : 'dashboard-collapsed';

    const navigate = useNavigate();

    const onShowDetails = () => {
        navigate("/store-details");
    };

    const toggleMapView = () => {
        setMapVisible(prevMapVisible => !prevMapVisible);
    };

    const onCreate = () =>{
        
    }

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        const validationErrors: { [key: string]: string } = {};

        if (!changeProductCategory) {
            validationErrors.changeProductCategory = 'Please select product category';
        } else {
            delete validationErrors['changeProductCategory'];
        }

        if (!createToDate) {
            validationErrors.createToDate = 'Please select from date';
        } else {
            delete validationErrors['createToDate'];
        }

        setErrors(validationErrors);
        !Object.keys(validationErrors).length && onCreate()
    };

    const onChangeProduct = (e: ChangeEvent<HTMLSelectElement>) => {
        setChangeProductCategory(e.target.value);
    };

    const toDate = (e: ChangeEvent<HTMLInputElement>) => {
        setCreateToDate(e.target.value);
    };

    return (
        <>
            <MainPage1
                sidebarVisible={sidebarVisible}
                toggleSidebar={toggleSidebar}
                backgroundColor={backgroundColor}
                // backgroundColor={backgroundColor}
                textClass={textClass}
            />
            {/* <!-- page-wrapper Start       --> */}
            <div className={`page-wrapper compact-wrapper ${dashboardClass}`} id="pageWrapper">
                <div className="page-body-wrapper sidebar-icon">
                    <div className="page-body">
                        <div className="container-fluid">
                            <div className="page-header">
                                <div style={{
                                    display: 'flex', justifyContent: 'space-between'
                                }}>
                                    <div style={{ textAlign: 'justify' }}>
                                        <h3 >Explore Space</h3>
                                        <div style={{ display: 'flex' }}>
                                            <a href="user-details">Dashboard /</a> <p>ExploreSpaces</p>
                                        </div>
                                    </div>

                                    <div className="d-flex" >
                                        <div className="media">
                                            <label className="col-form-label m-r-10">Show Map View</label>
                                            <div className="media-body text-end switch-sm">
                                                <label className="switch">
                                                    <input type="checkbox" onClick={toggleMapView} /><span className="switch-state"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="container-fluid ">
                            <div className="row">
                                <div className="col-sm-12">
                                    <form method="" onSubmit={handleSubmit}>
                                        <div className="card" style={{ textAlign: 'justify', height: '300px' }}>

                                            <div className="card-body">

                                                <div className="row" >

                                                    <div className="col-md-4" style={{ marginBottom: '15px' }}>
                                                        <div className="mb-3">
                                                            <label className="form-label"> What is your product category <span className=" mand_error">*</span></label>
                                                            <select className="form-select"
                                                                onChange={onChangeProduct}
                                                                value={changeProductCategory}
                                                            >
                                                                <option>-Select Product Category</option>
                                                                {jsonData.map(item => (
                                                                    <option key={item.id} value={item.id}>
                                                                        {item.name}
                                                                    </option>
                                                                ))}
                                                               
                                                            </select>
                                                            {errors.changeProductCategory && (
                                                                <span style={{ color: 'red' }}>
                                                                    {errors.changeProductCategory}
                                                                </span>
                                                            )}
                                                        </div>
                                                        {/* <small>(Pre-fills search parameters based on campaign details)</small> */}
                                                    </div>


                                                    <div className="col-md-4">
                                                        <div className="mb-3">
                                                            <label className="form-label" > From <span className="mand_error">*</span></label>
                                                            <input
                                                                className="form-control"
                                                                id=" "
                                                                type="date"
                                                                placeholder=" "
                                                                onChange={toDate}
                                                                value={createToDate}
                                                            />
                                                            {errors.createToDate && (
                                                                <span style={{ color: 'red' }}>
                                                                    {errors.createToDate}
                                                                </span>
                                                            )}
                                                        </div>

                                                    </div>
                                                    <div className="col-md-4">
                                                        <div className="mb-3">
                                                            <label className="form-label" > No of Months <span className="mand_error">*</span></label>
                                                            <select className="form-select">
                                                                <option>-Select-</option>
                                                                <option>1</option>
                                                                <option>2</option>
                                                                <option>3</option>
                                                                <option>4</option>
                                                                <option>5</option>
                                                                <option>6</option>
                                                                <option>7</option>
                                                                <option>8</option>
                                                                <option>9</option>
                                                                <option>10</option>
                                                                <option>11</option>
                                                                <option>12</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div className="col-md-4">
                                                        <div className="mb-3">
                                                            <label className="from-label"> State</label>
                                                            <select className="form-select">
                                                                <option>-Select State-</option>
                                                                <option>Telangana</option>
                                                                <option>Andhra Pradesh</option>
                                                                <option>Arunachal Pradesh</option>
                                                                <option>Assam</option>
                                                                <option>Bihar</option>
                                                                <option>Chattisgarh</option>
                                                                <option>Goa</option>
                                                                <option>Gujarat</option>
                                                                <option>Haryana</option>
                                                                <option>Himachal Pradesh</option>
                                                                <option>Jharkhand</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div className="col-md-4">
                                                        <div className="mb-3">
                                                            <label className="from-label" > City </label>
                                                            <select className="form-select">
                                                                <option>-Select-</option>
                                                                <option>1</option>
                                                                <option>2</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div className="col-md-3">
                                                        <button className="btn custom_btn" type="submit" style={{ marginTop: "28px" }} >Search</button>
                                                        <button className="btn " style={{ marginTop: "28px", marginLeft: '5px', backgroundColor: 'lightgray' }}>Reset</button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    {mapVisible &&
                                        <div className="card">
                                            <div className="card-body p-2">

                                                <div>
                                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30450.5617187963!2d78.45026631865177!3d17.444381226833194!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb90a3ed28854f%3A0x20084b938c2f1b8c!2sBegumpet%2C%20Hyderabad%2C%20Telangana!5e0!3m2!1sen!2sin!4v1650883406947!5m2!1sen!2sin" width="100%" height="400" style={{ border: "0" }} loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
                                                </div>

                                            </div>

                                        </div>
                                    }

                                    <div className="card">
                                        <div className="card-body p-2"  >
                                            <div className="col-md-12 ">
                                                <div className="card">
                                                    <div className="card-body dark_tab_blk p-0">
                                                        <div className="card-body p-2">
                                                            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '30px', marginTop: '20px' }}>
                                                                <div >
                                                                    <label>Show</label>
                                                                    <select name="example_length" aria-controls="examples" style={{ margin: '0 10px', padding: "0 10px", height: "2.7142em", borderColor: "#e6edef", }}>
                                                                        <option value={"10"}>10</option>
                                                                        <option value={"25"}>25</option>
                                                                        <option value={"50"}>50</option>
                                                                        <option value={"100"}>100</option>
                                                                    </select>
                                                                    <label >entries</label>
                                                                </div>
                                                                <label >
                                                                    Search:
                                                                    <input type="search" aria-controls="example" style={{ height: '37px', border: "1px solid #efefef", marginLeft: "10px" }} />
                                                                </label>
                                                            </div>
                                                        </div>

                                                        <table width="100%" className="table table-bordered display" style={{ fontSize: "12px", }} >
                                                            <thead className="sorting_disabled ui-state-default sorting_asc">
                                                                <tr style={{ backgroundColor: "#e7e5fd " }}>
                                                                    <td style={{ width: "133px" }}>S.No</td>
                                                                    <td style={{ width: "182px" }}>Store Name</td>
                                                                    <td style={{ width: "119px" }}>Location</td>
                                                                    <td style={{ width: "119px" }}>City</td>
                                                                    <td style={{ width: "80px" }}>Store Size (Sft)</td>
                                                                    <td style={{ width: "102px" }}>Available <br />Spaces</td>
                                                                    <td style={{ width: "112px" }}> Footfalls</td>
                                                                    <td style={{ width: "115px" }}>Actions</td>
                                                                </tr>
                                                            </thead>
                                                            <tbody className="tbody-td">
                                                                <tr>
                                                                    <td>1</td>
                                                                    <td>Ratnadeep Retail <br /> Private Limited</td>
                                                                    <td ><i className="fa fa-map-marker fa_ic"></i> Begumpet</td>
                                                                    <td >Hyderabad</td>
                                                                    <td >3000</td>
                                                                    <td >4</td>
                                                                    <td>5000</td>
                                                                    <td ><button className="btn btn-xs my_btn_5 text-white my_btntt" onClick={onShowDetails}>View</button></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>2</td>
                                                                    <td >Ratnadeep Retail <br /> Private Limited</td>
                                                                    <td > <i className="fa  fa-map-marker fa_ic"></i> Begumpet</td>
                                                                    <td>Hyderabad</td>
                                                                    <td >3000</td>
                                                                    <td>4</td>
                                                                    <td >5000</td>
                                                                    <td ><button className="btn btn-xs my_btn_5 text-white my_btntt">View</button></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div style={{ display: 'flex', marginTop: '15px' }}>
                                                        <label style={{ marginTop: '3px', paddingLeft: "10px" }}>Showing 0 to 0 of 0 entries</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* <Footer /> */}
            </div>
        </>
    );
};

export default ExploreSpace;
