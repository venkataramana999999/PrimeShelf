import React from 'react'
import './sidebar.css';

function Sidebar({ sidebarVisible, backgroundColor, textClass}:any) {
  console.log(backgroundColor, 'backgroundColor')

  return (
    <>
      <header className={`main-nav ${sidebarVisible ? 'show-sidebar' : 'hide-sidebar'}`}>
        <nav style={{ backgroundColor: backgroundColor }}>
          <div className="main-navbar">
            <div className="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
            <div id="mainnav">
              <ul className="nav-menu custom-scrollbar">
                <div className="job-sidebar">
                  <div className="job-left-aside custom-scrollbar">
                    <div className="default-according style-1 faq-accordion job-accordion" id="accordionoc" style={{ backgroundColor: backgroundColor }}>
                      <div className="row">
                        <div className="col-xl-12" >
                          <div className="card mb-2" style={{ backgroundColor: backgroundColor }}>
                            <div className="card-header cardmn_pad filt_bgcol" style={{ backgroundColor: backgroundColor }}>
                              <h5 className="mb-0 p-0">
                                <button className={`btn btn-link ps-0 ${textClass}`} data-bs-toggle="collapse"
                                  data-bs-target="#collapseicon_filer3" aria-expanded="true"
                                  aria-controls="collapseicon2">Type of Space</button>
                              </h5>
                            </div>
                            <div className="collapse show" id="collapseicon_filer3" data-parent="#collapseicon_filer3"
                              aria-labelledby="collapseicon2">
                              <div className="card-body animate-chk">
                                <label className={`d-block ${textClass}`} htmlFor="chk-ani11">
                                  <input className="checkbox_animated" id="chk-ani11" type="checkbox" /> Gandola
                                </label>
                                <label className={`d-block ${textClass}`} htmlFor="chk-ani12">
                                  <input className="checkbox_animated" id="chk-ani12" type="checkbox" /> Side Rack
                                </label>
                                <label className={`d-block ${textClass}`} htmlFor="chk-ani13">
                                  <input className="checkbox_animated" id="chk-ani13" type="checkbox" /> Payment Counters
                                </label>
                                <label className={`d-block ${textClass}`} htmlFor="chk-ani14">
                                  <input className="checkbox_animated" id="chk-ani14" type="checkbox" /> Fridge
                                </label>

                                <label className={`d-block ${textClass}`} htmlFor="chk-ani15">
                                  <input className="checkbox_animated" id="chk-ani15" type="checkbox" /> Back Rack
                                </label>

                                <label className={`d-block ${textClass}`} htmlFor="chk-ani16">
                                  <input className="checkbox_animated" id="chk-ani16" type="checkbox" /> Left Wall Rack
                                </label>
                                <label className={`d-block ${textClass}`} htmlFor="chk-ani16">
                                  <input className="checkbox_animated" id="chk-ani16" type="checkbox" /> Right Wall Rack
                                </label>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-xl-12">
                          <div className="card mb-2" style={{ backgroundColor: backgroundColor }}>
                            <div className="card-header cardmn_pad filt_bgcol" style={{ backgroundColor: backgroundColor }}>
                              <h5 className="mb-0 p-0">
                                <button className={`btn btn-link ps-0 ${textClass}`} data-bs-toggle="collapse"
                                  data-bs-target="#collapseicon_filer5" aria-expanded="true"
                                  aria-controls="collapseicon4">Price</button>
                              </h5>
                            </div>
                            <div className="collapse show" id="collapseicon_filer5" data-parent="#collapseicon_filer5"
                              aria-labelledby="collapseicon4">
                              <div className="card-body animate-chk">
                                <div className="form-group row mb-0">
                                  <div className="col-xl-12">
                                    <input id="u-range-05" type="text" />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-xl-12">
                          <div className="card mb-2">
                            <div className="card-header cardmn_pad filt_bgcol" style={{ backgroundColor: backgroundColor }}>
                              <h5 className="mb-0 p-0">
                                <button className={`btn btn-link ps-0 ${textClass}`} data-bs-toggle="collapse"
                                  data-bs-target="#collapseicon_filer6" aria-expanded="true"
                                  aria-controls="collapseicon4">No of footfalls per month</button>
                              </h5>
                            </div>
                            <div className="collapse show" id="collapseicon_filer6" data-parent="#collapseicon_filer6" style={{ backgroundColor: backgroundColor }}
                              aria-labelledby="collapseicon4">
                              <div className="card-body animate-chk">
                                <div className="form-group row mb-0">
                                  <div className="col-xl-12">
                                    <input id="u-range-055" type="text" />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-xl-12">
                          <div className="card mb-2" style={{ backgroundColor: backgroundColor }}>
                            <div className="card-header cardmn_pad filt_bgcol" style={{ backgroundColor: backgroundColor }}>
                              <h5 className="mb-0 p-0">
                                <button className={`btn btn-link ps-0 ${textClass}`} data-bs-toggle="collapse"
                                  data-bs-target="#collapseicon_filer8" aria-expanded="true"
                                  aria-controls="collapseicon4">Store Size (Sq. Ft)</button>
                              </h5>
                            </div>
                            <div className="collapse show" id="collapseicon_filer8" data-parent="#collapseicon_filer8"
                              aria-labelledby="collapseicon4">
                              <div className="card-body animate-chk">
                                <div className="form-group row mb-0">
                                  <div className="col-xl-12">
                                    <input id="u-range-088" type="text" />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </ul>
            </div>
            <div className="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
          </div>
        </nav>
      </header>
     <header className="main-nav">
          <nav>
            <div className="main-navbar">
              <div className="left-arrow" id="left-arrow">
                <i data-feather="arrow-left"></i>
              </div>
              <div id="mainnav">
                <ul className="nav-menu custom-scrollbar">
                  <div className="job-sidebar">
                    <div className="job-left-aside custom-scrollbar">
                      <div
                        className="default-according style-1 faq-accordion job-accordion"
                        id="accordionoc"
                      >
                        <div className="row">
                          <div className="col-xl-12">
                            <div className="card mb-2">
                              <div className="card-header filt_bgcol btn" style={{ height: '30px', backgroundColor: '#EDE3FF' }}>
                                <h5 className="mb-8 p-0" >
                                  <button
                                    className="btn btn-link ps-0"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#collapseicon_filer3"
                                    aria-expanded="true"
                                    aria-controls="collapseicon2"
                                    style={{ marginTop: '-15px' }}
                                  >
                                    Type of Space
                                  </button>
                                </h5>
                              </div>
                              <div
                                className="collapse show"
                                id="collapseicon_filer3"
                                data-parent="#collapseicon_filer3"
                                aria-labelledby="collapseicon2"
                              >
                                <div className="card-body animate-chk">
                                  <label className="d-block" htmlFor="chk-ani11">
                                    <input
                                      className="checkbox_animated"
                                      id="chk-ani11"
                                      type="checkbox"
                                    />{' '}
                                    Gandola
                                  </label>
                                  <label className="d-block" htmlFor="chk-ani12">
                                    <input
                                      className="checkbox_animated"
                                      id="chk-ani12"
                                      type="checkbox"
                                    />{' '}
                                    Side Rack
                                  </label>
                                  <label className="d-block" htmlFor="chk-ani13">
                                    <input
                                      className="checkbox_animated"
                                      id="chk-ani13"
                                      type="checkbox"
                                    />{' '}
                                    Payment Counters
                                  </label>
                                  <label className="d-block" htmlFor="chk-ani14">
                                    <input
                                      className="checkbox_animated"
                                      id="chk-ani14"
                                      type="checkbox"
                                    />{' '}
                                    Fridge
                                  </label>

                                  <label className="d-block  " htmlFor="chk-ani15">
                                    <input
                                      className="checkbox_animated"
                                      id="chk-ani15"
                                      type="checkbox"
                                    />{' '}
                                    Back Rack
                                  </label>

                                  <label className="d-block  " htmlFor="chk-ani16">
                                    <input
                                      className="checkbox_animated"
                                      id="chk-ani16"
                                      type="checkbox"
                                    />{' '}
                                    Left Wall Rack
                                  </label>
                                  <label className="d-block  " htmlFor="chk-ani16">
                                    <input
                                      className="checkbox_animated"
                                      id="chk-ani16"
                                      type="checkbox"
                                    />{' '}
                                    Right Wall Rack
                                  </label>
                                  <label className="d-block  " htmlFor="chk-ani16">
                                    <input
                                      className="checkbox_animated"
                                      id="chk-ani16"
                                      type="checkbox"
                                    />{' '}
                                    Handy Cam
                                  </label>
                                  <label className="d-block  " htmlFor="chk-ani16">
                                    <input
                                      className="checkbox_animated"
                                      id="chk-ani16"
                                      type="checkbox"
                                    />{' '}
                                    FCU
                                  </label>
                                  <label className="d-block  " htmlFor="chk-ani16">
                                    <input
                                      className="checkbox_animated"
                                      id="chk-ani16"
                                      type="checkbox"
                                    />{' '}
                                    Vegetables
                                  </label>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-xl-12">
                            <div className="card mb-2">
                              <div className="card-header cardmn_pad filt_bgcol" style={{ height: '30px', backgroundColor: '#EDE3FF' }}>
                                <h5 className="mb-0 p-0">
                                  <button
                                    className="btn btn-link ps-0"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#collapseicon_filer5"
                                    aria-expanded="true"
                                    aria-controls="collapseicon4"
                                    style={{ marginTop: '-15px' }}
                                  >
                                    Price
                                  </button>
                                </h5>
                              </div>
                              <div
                                className="collapse show"
                                id="collapseicon_filer5"
                                data-parent="#collapseicon_filer5"
                                aria-labelledby="collapseicon4"
                              >
                                <div className="card-body animate-chk">
                                  <div className="form-group row mb-0">
                                    <div className="col-xl-12">
                                      <input id="u-range-05" type="text" />
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-xl-12">
                            <div className="card mb-2">
                              <div className="card-header cardmn_pad filt_bgcol" style={{ height: '30px', backgroundColor: '#EDE3FF' }}>
                                <h5 className="mb-0 p-0">
                                  <button
                                    className="btn btn-link ps-0"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#collapseicon_filer6"
                                    aria-expanded="true"
                                    aria-controls="collapseicon4"
                                    style={{ marginTop: '-15px' }}
                                  >
                                    No of footfalls per month
                                  </button>
                                </h5>
                              </div>
                              <div
                                className="collapse show"
                                id="collapseicon_filer6"
                                data-parent="#collapseicon_filer6"
                                aria-labelledby="collapseicon4"
                              >
                                <div className="card-body animate-chk">
                                  <div className="form-group row mb-0">
                                    <div className="col-xl-12">
                                      <input id="u-range-055" type="text" />
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-xl-12">
                            <div className="card mb-2">
                              <div className="card-header cardmn_pad filt_bgcol" style={{ height: '30px', backgroundColor: '#EDE3FF' }}>
                                <h5 className="mb-0 p-0">
                                  <button
                                    className="btn btn-link ps-0"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#collapseicon_filer8"
                                    aria-expanded="true"
                                    aria-controls="collapseicon4"
                                    style={{ marginTop: '-15px' }}
                                  >
                                    Store Size (Sq. Ft)
                                  </button>
                                </h5>
                              </div>
                              <div
                                className="collapse show"
                                id="collapseicon_filer8"
                                data-parent="#collapseicon_filer8"
                                aria-labelledby="collapseicon4"
                              >
                                <div className="card-body animate-chk">
                                  <div className="form-group row mb-0">
                                    <div className="col-xl-12">
                                      <input id="u-range-088" type="text" />
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </ul>
              </div>
              <div className="right-arrow" id="right-arrow">
                <i data-feather="arrow-right"></i>
              </div>
            </div>
          </nav>
        </header>  
    </>
  )
}

export default Sidebar
